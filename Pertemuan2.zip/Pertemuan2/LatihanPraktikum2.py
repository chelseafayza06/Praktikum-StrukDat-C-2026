#Soal1
thislist = [15, 50, 75, 30, 25, 40, 100]

thislist.sort()
print(thislist)

rata_rata = sum(thislist) / len(thislist)
print(rata_rata)


#Soal 2
# Diberikan tuple barang
barang = ("B001", "Laptop Gaming", 15000000)

#Akses dan tampilkan harga barang dari tuple
harga_barang = barang[2]
print("Harga barang:", harga_barang)

#Menggunakan teknik unpacking
kode, nama, harga = barang

print("Kode barang:", kode)
print("Nama barang:", nama)
print("Harga barang:", harga)



#Soal 3


